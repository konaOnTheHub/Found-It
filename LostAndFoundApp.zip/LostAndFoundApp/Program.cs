﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace UserRegistrationApp
{
    class User
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
    }

    class Program
    {
        static List<User> users = new List<User>();

        static void Main(string[] args)
        {
            Console.WriteLine("==== User Registration ====\n");

            bool keepRunning = true;

            while (keepRunning)
            {
                // --- Name validation ---
                string fullName;
                while (true)
                {
                    Console.Write("Enter Full Name: ");
                    fullName = Console.ReadLine();
                    if (Regex.IsMatch(fullName, @"^[a-zA-Z\s]+$"))
                        break;
                    Console.WriteLine("❌ Name can only contain letters and spaces.\n");
                }

                // --- Email input (no strict validation, can be added if needed) ---
                Console.Write("Enter Email Address: ");
                string email = Console.ReadLine();

                // --- Phone number validation ---
                string phoneNumber;
                while (true)
                {
                    Console.Write("Enter Phone Number: ");
                    phoneNumber = Console.ReadLine();
                    if (Regex.IsMatch(phoneNumber, @"^\d+$"))
                        break;
                    Console.WriteLine("❌ Phone number can only contain digits.\n");
                }

                // --- Address input ---
                Console.Write("Enter Address: ");
                string address = Console.ReadLine();

                var user = new User
                {
                    FullName = fullName,
                    Email = email,
                    PhoneNumber = phoneNumber,
                    Address = address
                };

                users.Add(user);

                Console.WriteLine("\n✅ User Registered Successfully!\n");

                Console.Write("Would you like to register another user? (y/n): ");
                var input = Console.ReadLine().Trim().ToLower();
                keepRunning = input == "y";
            }

            Console.WriteLine("\n=== All Registered Users ===\n");

            foreach (var user in users)
            {
                Console.WriteLine($"Name: {user.FullName}");
                Console.WriteLine($"Email: {user.Email}");
                Console.WriteLine($"Phone: {user.PhoneNumber}");
                Console.WriteLine($"Address: {user.Address}");
                Console.WriteLine("--------------------------");
            }

            Console.WriteLine("\nPress any key to exit.");
            Console.ReadKey();
        }
    }
}
